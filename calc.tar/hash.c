/* Fill in your Name and GNumber in the following two comment fields
 * Name:Indrika Roy
 * GNumber:G01210152
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "node.h"
#include "hash.h"

/* (IMPLEMENT THIS FUNCTION)
 * In this function, you will create a new Symtab struct.
 * Follow the Directions in the Project Documentation for this Function
 * Return the pointer to the new symtab.
 * On any memory errors, return NULL
 */
Symtab *hash_initialize()
{
	/* Implement this function */
	{
		int i = 0; 								//initialising index of hash table
		Symtab *new_Symtab = malloc(sizeof(Symtab));
		new_Symtab->table = malloc(sizeof(Symbol *) * (HASH_TABLE_INITIAL));
		new_Symtab->capacity = HASH_TABLE_INITIAL;
		new_Symtab->size = 0;
		for (i = 0; i < (new_Symtab->capacity); i++)
		{
			new_Symtab->table[i] = NULL;
		}
		if (new_Symtab == NULL)
		{
			return NULL;
		}
		return new_Symtab;
	}
}

/* (IMPLEMENT THIS FUNCTION)
 * Destroy your Symbol Table.
 * Follow the Directions in the Project Documentation for this Function
 * Return on any memory errors.
 */

void hash_destroy(Symtab *symtab)
{
	/* Implement this function */
	int i = 0; 										
	{
		if (symtab == NULL)
		{
			return;
		}
		else
		{
			for (i = 0; i < symtab->capacity; i++)
			{
				Symbol *walker = symtab->table[i]; 		//for traversing the hash table
				free(walker);
				return;
			}
		}
	}
}

/* (IMPLEMENT THIS FUNCTION)
 * Return the capacity of the table inside of symtab.
 * If symtab is NULL, return -1;
 */
int hash_get_capacity(Symtab *symtab)
{
	/* Implement this function */
	return symtab->capacity;
}

/* (IMPLEMENT THIS FUNCTION)
 * Return the number of used indexes in the table (size) inside of symtab.
 * If symtab is NULL, return -1;
 */
int hash_get_size(Symtab *symtab)
{
	/* Implement this function */
	return symtab->size;
}

/* (IMPLEMENT THIS FUNCTION)
 * Adds a new Symbol to the symtab via Hashing.
 * Follow the Directions in the Project Documentation for this Function
 * If symtab is NULL, there are any malloc errors, or if any rehash fails, return -1;
 * Otherwise, return 0;
 */
int hash_put(Symtab *symtab, char *var, int val)
{
	/* Implement this function */
	int index = 0;
	long load = (symtab->size / symtab->capacity);
	Symbol *new_Symbol = malloc(sizeof(Symbol));
	strcpy((new_Symbol)->variable, var);
	(new_Symbol)->val = val;
	(new_Symbol)->next = NULL;
	if (load >= 2.0) 							//evaluating the load of hash table
	{
		hash_rehash(symtab, (symtab->capacity) * 2);
	}
	index = hash_code(var) % symtab->capacity;
	if (symtab->table[index] == NULL)
	{
		symtab->table[index] = new_Symbol;
		symtab->size++;
		return 0;
	}
	else
	{
		Symbol *walker = symtab->table[index];		//for traversing
		while (walker->next != NULL)
		{
			walker = walker->next;
		}
		walker->next = new_Symbol;
		symtab->size++;
	}
	return 0;
}

/* (IMPLEMENT THIS FUNCTION)
 * Gets the Symbol for a variable in the Hash Table.
 * Follow the Directions in the Project Documentation for this Function
 * On any NULL symtab or memory errors, return NULL
 */
Symbol *hash_get(Symtab *symtab, char *var)
{
	/* Implement this function */
	int index = 0; //initialising index of hash table
	index = hash_code(var) % (symtab->capacity);
	if ((symtab->table[index]->next) == NULL)
	{
		Symbol *s = symbol_copy(symtab->table[index]);
		return s;
	}
	else
	{
		Symbol *walker = symtab->table[index]; 				//used for traversing
		while (walker != NULL)
		{
			if (strcmp(var, walker->variable) == 0)
			{
				Symbol *s = symbol_copy(walker);
				return s;
			}
			walker = walker->next;
		}
		return 0;
		return NULL;
	}
}

/* (IMPLEMENT THIS FUNCTION)
 * Doubles the size of the Array in symtab and rehashes.
 * Follow the Directions in the Project Documentation for this Function
 * If there were any memory errors, set symtab->array to NULL
 * If symtab is NULL, return immediately.
 */
void hash_rehash(Symtab *symtab, int new_capacity)
{
	/* Implement this function */
	int index = 0;									
	int i = 0;										
	Symbol **new_table = malloc(sizeof(Symbol *) * (HASH_TABLE_INITIAL)*2); //allocating double the capacity of hash table to new table for rehashing
	for (i = 0; i < ((HASH_TABLE_INITIAL)*2); i++)
	{
		new_table[i] = NULL;
	}
	for (i = 0; i < (symtab->capacity); i++)
	{
		Symbol *s = symtab->table[i];
		if (s->next == NULL)
		{
			index = hash_code(s->variable) % (new_capacity); //calculating index where variable will be stored in hash table using hash_code
			Symbol *s1 = malloc(sizeof(Symbol));
			s1->val = s->val;
			strcpy(s1->variable, s->variable);
			s1->next = NULL;
			if (new_table[index] == NULL)
			{
				new_table[index] = s1;
			}
			else
			{
				Symbol *walker = new_table[index];
				while ((walker->next) != NULL)
				{
					walker = walker->next;
				}
				if ((walker->next) == NULL)
				{
					walker->next = s1;
				}
			}
		}
		else
		{
			while (s != NULL)
			{
				index = hash_code(s->variable) % (new_capacity);
				Symbol *s1 = malloc(sizeof(Symbol));
				s1->val = s->val;
				strcpy(s1->variable, s->variable);
				s1->next = NULL;
				if (new_table[index] == NULL)
				{
					new_table[index] = s1;
				}
				else
				{
					Symbol *walker = new_table[index];
					while ((walker->next) != NULL)
					{
						walker = walker->next;
					}
					if ((walker->next) == NULL)
					{
						walker->next = s1;
					}
				}
				s = s->next;
			}
		}
	}
	symtab->table = new_table;
	symtab->capacity = new_capacity;
	return;
}

/* Implemented for you.
 * Provided function to print the symbol table */
void hash_print_symtab(Symtab *symtab)
{
	if (symtab == NULL)
	{
		return;
	}
	printf("|-----Symbol Table [%d size/%d cap]\n", symtab->size, symtab->capacity);
	int i = 0;
	Symbol *walker = NULL;

	/* Iterate every index, looking for symbols to print */
	for (i = 0; i < symtab->capacity; i++)
	{
		walker = symtab->table[i];
		/* For each found linked list, print every symbol therein */
		while (walker != NULL)
		{
			printf("| %10s: %d \n", walker->variable, walker->val);
			walker = walker->next;
		}
	}
	return;
}

/* This function is written for you.
 * This computes the hash function for a String
 */
long hash_code(char *var)
{
	long code = 0;
	int i;
	int size = strlen(var);
	for (i = 0; i < size; i++)
	{
		code = (code + var[i]);
		if (size == 1 || i < (size - 1))
		{
			code *= 128;
		}
	}
	return code;
}
