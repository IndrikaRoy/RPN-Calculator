/* Fill in your Name and GNumber in the following two comment fields
 * Name: Indrika Roy
 * GNumber: G01210152
 */
#include <stdio.h>
#include <stdlib.h>

#include "node.h"
#include "stack.h"

/* (IMPLEMENT THIS FUNCTION)
 * Create a new Stack_head struct on the Heap and return a pointer to it.
 * Follow the Directions in the Project Documentation for this Function
 * On any malloc errors, return NULL
 */
Stack_head *stack_initialize()
{
	/* Implement this function */
	Stack_head *head = malloc(sizeof(Stack_head)); //allocating space for dummy node "head"
	if (head == NULL)
	{
		return NULL;
	}
	else
	{
		head->count = 0;
		head->top = NULL;
		return head;
	}
}

/* (IMPLEMENT THIS FUNCTION)
 * Destroy a stack.
 * Follow the Directions in the Project Documentation for this Function
 * If head is NULL, you can just return.
 */
void stack_destroy(Stack_head *head)
{
	/* Implement this function */
	if (head == NULL) 								//stack is empty
	{
		return;
	}
	else
	{
		Node *walker = head->top; 					//for traversing
		Node *reaper = head->top;
		while (walker != NULL)
		{
			walker = walker->next;
			free(reaper);
			reaper = walker;
		}
		free(head);
	}
}
/* (IMPLEMENT THIS FUNCTION)
 * Push a new Token on to the Stack.
 * Follow the Directions in the Project Documentation for this Function
 * On any malloc errors, return -1.
 * If there are no errors, return 0.
 */
int stack_push(Stack_head *stack, Token *tok)
{
	/* Implement this function */

	Node *node_create = malloc(sizeof(Node)); 			//creating a new  node
	node_create->next = NULL;
	node_create->tok = tok;
	if (stack->top == NULL)
	{
		stack->top = node_create;					//assigning new node to the top of stack
		(stack->count)++;
	}
	else
	{
		(node_create)->next = stack->top;
		(stack->count)++;
		stack->top = node_create;
	}
	return 0;
}

/* (IMPLEMENT THIS FUNCTION)
 * Pop a Token off of the Stack.
 * Follow the Directions in the Project Documentation for this Function
 * If the stack was empty, return NULL.
 */
Token *stack_pop(Stack_head *stack)
{
	/* Implement this function */
	if (stack->top == NULL)
	{
		return NULL;
	}
	else
	{
		Node *walker = stack->top;				//for traversing
		(stack->top) = (stack->top)->next;
		(stack->count)--;
		return walker->tok;
	}
}

/* (IMPLEMENT THIS FUNCTION)
 * Return the token in the stack node on the top of the stack
 * Follow the Directions in the Project Documentation for this Function
 * If the stack is NULL, return NULL.
 * If the stack is empty, return NULL.
 */
Token *stack_peek(Stack_head *stack)
{
	/* Implement this function */
	if (stack->top == NULL)
	{
		return NULL;
	}
	else
	{
		return (stack->top)->tok;
	}
}
/* (IMPLEMENT THIS FUNCTION)
 * Return the number of nodes in the stack.
 * Follow the Directions in the Project Documentation for this Function
 * If stack is NULL, return -1.
 * Return 1 if the stack is empty or 0 otherwise.
 */
int stack_is_empty(Stack_head *stack)
{
	/* Implement this function */
	int node_count = 0;
	Node *node = NULL; //this will count the number of nodes
	if (stack->top == NULL)
	{
		return -1;
	}
	else if ((stack->top) != NULL)
	{
		node = stack->top;
		while ((node->next) != NULL)
		{
			node = node->next;
			node_count++;
		}
		return node_count;
	}
}
/* These two functions are written for you.
 * It recurses the stack and prints out the tokens in reverse order
 * eg. top->2->4->1->8 will print at Stack: 8 1 4 2
 * eg. stack_push(5) will then print Stack: 8 1 4 2 5
 */

/* This is implemented for you.
 * Recursive print. (Local function)
 * Base Case: node == NULL, return
 * Recursive Case: call print_node(node->next, print_data), then print node.
 */
static void print_node(Node *node)
{
	if (node == NULL)
	{
		return;
	}
	token_print(node->tok);
	print_node(node->next);
	return;
}

/* This is implemented for you.
 * Setup function for the recursive calls.  Starts printing with stack->top
 */
void stack_print(Stack_head *stack)
{
	if (stack == NULL)
	{
		return;
	}
	printf("|-----Program Stack\n");
	printf("| ");
	print_node(stack->top);
	printf("\n");
	return;
}
