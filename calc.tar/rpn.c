/* Fill in your Name and GNumber in the following two comment fields
 * Name: Indrika Roy
 * GNumber: G01210152
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "stack.h"
#include "token.h"
#include "hash.h"

/* Local Function Declarations (that you need to finish implementing) */
static int read_file(char *filename, char *line);
static int parse_token(Symtab *symtab, Stack_head *stack, Token *tok);

/* Pre-Written Local Function Declarations */
static void print_header(char *filename, int step);
static void print_step_header(int step);
static void print_step_footer(Symtab *symtab, Stack_head *stack);
static void print_step_output(int val);

/* Defines the largest line that can be read from a file */
#define MAX_LINE_LEN 255

/* This has been written for you.
 * Main function to run your program (written for you).
 * 1) Opens the file using the passed in filename. (your function)
 * -- If the file is not found (ie. fopen returns NULL), then exit(-1);
 * 2) Reads one line from the file.
 * -- The programs will all only be one line in size.
 * -- That line may be up to MAX_LINE_LEN long.
 * 3) Closes the file.
 * 4) Calls token_read_line(line, strlen(line))
 * -- This parses the line and prepares the tokens to be ready to get.
 * 5) While there are tokens remaining to parse: token_has_next() != 0
 * -- a) Get the next token: token_get_next()
 * 6) Parse the token (your function)
 * 7) Print out all of the relevant information
 */
int rpn(Stack_head *stack, Symtab *symtab, char *filename)
{
        int step = 0; /* Used to track the program steps */
        int ret = 0;
        char line[MAX_LINE_LEN];
        Token *tok = NULL;

        /* Complete the read_file function that is defined later in this file. */
        ret = read_file(filename, line);
        if (ret != 0)
        {
                printf("Error: Cannot Read File %s.  Exiting\n", filename);
                exit(-1);
        }

        /* Pass the line into the tokenizer to initialize that system */
        token_read_line(line, strlen(line));

        /* Prints out the nice program output header */
        print_header(filename, step);

        /* Iterate through all tokens */
        while (token_has_next())
        {
                /* Begin the next step of execution and print out the step header */
                step++; /* Begin the next step of execution */
                print_step_header(step);

                /* Get the next token */
                tok = token_get_next();
                /* Complete the implementation of this function later in this file. */
                ret = parse_token(symtab, stack, tok);
                if (ret != 0)
                {
                        printf("Critical Error in Parsing.  Exiting Program!\n");
                        exit(-1);
                }

                /* Prints out the end of step information */
                print_step_footer(symtab, stack);
        }

        return 0;
}

/* (IMPLEMENT THIS FUNCTION)
 * Local function to open a file or exit.
 * Follow the Directions in the Project Documentation for this Function
 * Open filename, read its contents (up to MAX_LINE_LEN) into line, then
 *   close the file and return 0.
 * On any file error, return -1.
 */
static int read_file(char *filename, char *line)
{
        FILE *fp = fopen(filename, "r");
        if (fp == NULL)
        {
                printf("Error");
                return -1;
        }
        else
        {
                fgets(line, MAX_LINE_LEN, fp);          //to read the contents from txt file
                fclose(fp);
                return 0;
        }
}
/* (IMPLEMENT THIS FUNCTION)
 * Parses the Token to implement the rpn calculator features
 * Follow the Directions in the Project Documentation for this Function
 * You may implement this how you like, but many small functions would be good!
 * If the token you are passed in is NULL, return -1.
 * If there are any memory errors, return -1.
 */
static int parse_token(Symtab *symtab, Stack_head *stack, Token *tok)
{
        int add = 1;
        int mult = 1;
        int minus = 1;
        int div = 1;

        if (tok == NULL)
        {
                return -1;
        }
        else if (tok->type == TYPE_ASSIGNMENT)          //if token is of assignment type
        {
                Token *var1 = stack_pop(stack);
                Token *var2 = stack_pop(stack);
                if (var1->type == TYPE_VARIABLE && var2->type == TYPE_VALUE)
                {
                        hash_put(symtab, (var1->variable), var2->value);
                }
                else
                {
                        hash_put(symtab, (var2->variable), var1->value);
                }
                token_free(var1);
                token_free(var2);
                return 0;
        }

        else if (tok->type == TYPE_OPERATOR)            //if the token is of operator type
        {
                if (tok->oper == OPERATOR_PLUS)         //to check different types of operators
                {
                        Token *var1 = stack_pop(stack);
                        Token *var2 = stack_pop(stack);
                        if (var1->type == TYPE_VARIABLE && var2->type == TYPE_VARIABLE)
                        {       //to get the symbols from hash table
                                Symbol *v1 = hash_get(symtab, var1->variable);
                                Symbol *v2 = hash_get(symtab, var2->variable);
                                add = (v1->val) + (v2->val);
                                Token *re = token_create_value(add);
                                stack_push(stack, re);
                                return 0;
                        }
                        else if (var1->type == TYPE_VALUE && var2->type == TYPE_VARIABLE)
                        {
                                Symbol *v2 = hash_get(symtab, var2->variable);
                                add = (var1->value) + (v2->val);
                                Token *re = token_create_value(add);
                                stack_push(stack, re);
                                return 0;
                        }
                        else if (var1->type == TYPE_VARIABLE && var2->type == TYPE_VALUE)
                        {
                                Symbol *v1 = hash_get(symtab, var1->variable);
                                add = (v1->val) + (var2->value);
                                Token *re = token_create_value(add);
                                stack_push(stack, re);
                                return 0;
                        }
                        else
                        {       //if the popped out elements are values
                                add = (var2->value) + (var1->value);
                                //output after addition of values
                                Token *re = token_create_value(add);
                                stack_push(stack, re);
                                //freeing the temporary tokens
                                token_free(var1);
                                token_free(var2);
                                return 0;
                        }
                }

                else if (tok->oper == OPERATOR_MINUS) //to check different types of operators
                {
                        Token *var1 = stack_pop(stack);
                        Token *var2 = stack_pop(stack);
                        if (var1->type == TYPE_VARIABLE && var2->type == TYPE_VARIABLE)
                        {
                                Symbol *v1 = hash_get(symtab, var1->variable); //calling hash_get() whenever variable is encountered in token
                                Symbol *v2 = hash_get(symtab, var2->variable);
                                minus = (v2->val) - (v1->val);
                                Token *re = token_create_value(minus);
                                stack_push(stack, re);
                                return 0;
                        }
                        else if (var1->type == TYPE_VALUE && var2->type == TYPE_VARIABLE)
                        {
                                Symbol *v2 = hash_get(symtab, var2->variable);
                                minus = (v2->val) - (var1->value);
                                Token *re = token_create_value(minus);
                                stack_push(stack, re);
                                return 0;
                        }
                        else if (var1->type == TYPE_VARIABLE && var2->type == TYPE_VALUE)
                        {
                                Symbol *v1 = hash_get(symtab, var1->variable);
                                minus = (var2->value) - (v1->val);
                                Token *re = token_create_value(minus);
                                stack_push(stack, re);
                                return 0;
                        }
                        else
                        {
                                minus = (var2->value) - (var1->value);
                                Token *re = token_create_value(minus);
                                stack_push(stack, re);
                                token_free(var1);
                                token_free(var2);
                                return 0;
                        }
                }
                else if (tok->oper == OPERATOR_MULT)
                {
                        Token *var1 = stack_pop(stack);
                        Token *var2 = stack_pop(stack);
                        if (var1->type == TYPE_VARIABLE && var2->type == TYPE_VARIABLE)
                        {
                                Symbol *v1 = hash_get(symtab, var1->variable);
                                Symbol *v2 = hash_get(symtab, var2->variable);
                                mult = (v1->val) * (v2->val);
                                Token *re = token_create_value(mult);
                                stack_push(stack, re);
                                return 0;
                        }
                        else if (var1->type == TYPE_VALUE && var2->type == TYPE_VARIABLE)
                        {
                                Symbol *v2 = hash_get(symtab, var2->variable);
                                mult = (var1->value) * (v2->val);
                                Token *re = token_create_value(mult);
                                stack_push(stack, re);
                                return 0;
                        }
                        else if (var1->type == TYPE_VARIABLE && var2->type == TYPE_VALUE)
                        {
                                Symbol *v1 = hash_get(symtab, var1->variable);
                                mult = (v1->val) * (var2->value);
                                Token *re = token_create_value(mult);
                                stack_push(stack, re);
                                return 0;
                        }
                        else
                        {
                                mult = (var2->value) * (var1->value);
                                Token *re = token_create_value(mult);
                                stack_push(stack, re);
                                token_free(var1);
                                token_free(var2);
                                return 0;
                        }
                }
                else if (tok->oper == OPERATOR_DIV)
                {
                        Token *var1 = stack_pop(stack);
                        Token *var2 = stack_pop(stack);
                        if (var1->type == TYPE_VARIABLE && var2->type == TYPE_VARIABLE)
                        {
                                Symbol *v1 = hash_get(symtab, var1->variable);
                                Symbol *v2 = hash_get(symtab, var2->variable);
                                div = (v1->val) / (v2->val);
                                Token *re = token_create_value(div);
                                stack_push(stack, re);
                                return 0;
                        }
                        else if (var1->type == TYPE_VALUE && var2->type == TYPE_VARIABLE)
                        {
                                Symbol *v2 = hash_get(symtab, var2->variable);
                                div = (var1->value) / (v2->val);
                                Token *re = token_create_value(div);
                                stack_push(stack, re);
                                return 0;
                        }
                        else if (var1->type == TYPE_VARIABLE && var2->type == TYPE_VALUE)
                        {
                                Symbol *v1 = hash_get(symtab, var1->variable);
                                div = (v1->val) / (var2->value);
                                Token *re = token_create_value(div);
                                stack_push(stack, re);
                                return 0;
                        }
                        else
                        {
                                div = (var2->value) / (var1->value);
                                Token *re = token_create_value(div);
                                stack_push(stack, re);
                                token_free(var1);
                                token_free(var2);
                                return 0;
                        }
                }
        }
        else if (tok->type == TYPE_VARIABLE)
        {
                stack_push(stack, tok);
                return 0;
        }
        else if (tok->type == TYPE_VALUE)
        {
                stack_push(stack, tok);
                return 0;
        }
        else if (tok->type == TYPE_PRINT)
        {       //to print out the output
                Symbol *prt = NULL;
                Token *tok1 = stack_pop(stack);
                if (tok1->type == TYPE_VARIABLE)
                {
                        prt = hash_get(symtab, tok1->variable);
                        print_step_output(prt->val);
                        return 0;
                }
                else
                {
                        print_step_output(tok1->value);
                        return 0;
                }
        }
}
/* This has been written for you.
 * Prints out the main output header
 */
static void print_header(char *filename, int step)
{
        printf("######### Beginning Program (%s) ###########\n", filename);
        printf("\n.-------------------\n");
        printf("| Program Step = %2d\n", step);
        token_print_remaining();
        printf("o-------------------\n");
}

/* This has been written for you.
 * Prints out the information at the top of each step
 */
static void print_step_header(int step)
{
        printf("\n.-------------------\n");
        printf("| Program Step = %2d\n", step++);
}

/* This has been written for you.
 * Prints out the output value (print token) nicely
 */
static void print_step_output(int val)
{
        printf("|-----Program Output\n");
        printf("| %d\n", val);
}

/* This has been written for you.
 * Prints out the information at the bottom of each step
 */
static void print_step_footer(Symtab *symtab, Stack_head *stack)
{
        hash_print_symtab(symtab);
        stack_print(stack);
        token_print_remaining();
        printf("o-------------------\n");
}
